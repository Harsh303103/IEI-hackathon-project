export const ICONS = ["fish", "poop", "weather"];
export const TICK_RATE = 3000;
export const SCENES = ["day", "rain"];
export const RAIN_CHANCE = 0.2;
