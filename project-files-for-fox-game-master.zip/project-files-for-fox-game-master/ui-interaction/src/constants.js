export const ICONS = ["fish", "poop", "weather"];
export const TICK_RATE = 3000;
